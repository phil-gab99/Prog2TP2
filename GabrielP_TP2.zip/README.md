# Progrmmation 2 - TP2

*Auteur: Philippe Gabriel, 20120600*

[Lien pour visionner le fichier](https://jbt.github.io/markdown-editor/#rVnLjtzGFd3zKwho0UljpiFrkYW0EmzLtjAGBMhJFkEW1WTNdAlskqpHY5Sv0S4aLbzKH/DHcs6tB8melmMjEjB295B13/ece2ue1G/scPfslzfPqmr7Mngd7PP6zcF0Zhx1/YPaW6O7q/rZ02+ePf3L06fbqvrHjdF9PQ7B1ifjzND32tadrm9NczDa/vNPf66qJ0+e1D/13g5taDxeqaqftaubw2Du48lG16Md3mlfu6H3OO5qF8xJ9d49r67rn4c+P9cOP7030yerj/iAL7Xq7zpl3Iuqxr/r+kbVFl+HPsv2Xtft9NCIeSLhfdD1O+jUvcObtdV9a/XCijHsO9OIPAcRPxj/Y9hf1XjSbZI2kaOc0/+qQ29O2jrdwe1W9Y7uH4e+xTddd0rEQPCdVcejov87+PR6o0zdDMexmx789LBQbvrWnEwbKI8uZr++77NfFLsxfWNaRqANOKmPCHb9y5sraobc6eF9MCN/p6Lv+A/OiShv1UkZSMfDk25gf62CRwBGZb3ulcFH2PGOFuI7rTsOBu84Z6j7iFAdtOWPyMP5xUkJele8OTJWiHVPaaNyiC0MGAIihoPMgXUsGpG0dP2sMq5w0DgmrlP12AVqhDGujp7iw+1gj9MDPqQcpLjnyNSsrBYRDRYOZSudbpCpXf29X8pvFUsGovS9QgqciLo1vQr3tRphUHNQBiZJiBbhZULxfgOF51mUQiphibbRBoaAUdGWJQgRXh9H+LBRnrHHrzaIb8+AqbBKbEqRiJoeTnh5VgZbDfuo9kN4XFE7OSNteQMnO+O8dmjK2GZSp7oOHl3vYhjiG7UzKNeoAAGYfu0l3CmUeOwt+jtYyGJMrPElGZvpoR/6hkFiGhDmDj/uGhVAAc5Nn2It4yvSczs9WIbRoegY333gowqZEUvYcTge+98zVizf3ysIJ6aPzDKCVEmHRqm7qvrbYBojvuBdjx5hIoz0KJVJ8xKQttsbsQMP0eb38vvtNvXpm2SFlPfChi+YUC9MyK3+rYYZt6pBBjx7Xb1jGqUS2qEJ4vhFAXMR61i0+XUXkdVbMz3gs+6Q6w6tUG9jrUcV21gZyYiDoqSicFz6FbWVKhBYGKClGQKjRetCamrpHcu6jVGIkLMODfGT5VpyXV/I9YulcesIaXqm7vjp3jQs4fFgxHrkUgxD1whkA/wMEa0brCvy2rMg4wRzhJJFu9vpk8uPd19IPlqMLkwPf6QKfsvLr+nhH/DuUfb57v9K/FxjXyf7pNkvtMbXbo//q0Wq7zSZyF0VPFtAIPB+LLhh+ItWZxyN0CrgSZVEFOLwdvvSWvWB1bXdJljdqFtOUkz8KtKMEWyDgGYQbdFcVVmduLm0JP29VaSDTXAQZF8UfT8qd1iqA/VMn3k+4qd+H6bPAuIMbTyMHPek+oSxMMbSkapF5lGP/LybBzEQsj8McRLKygqzQGYiOx0nIVQ2C3cPpmMlSXBFFlS0wZA3NqydpdR2wKwGQ/ZDaPh/c8SMmu2IFDfHsKpuVgF1pKPIYi4FSfiKT4Y9eFps8x8w+263r3/R9/6l1UqihZZ4wLu+gqyG0UH0zR4My87byGRmbo2KDIWHOP+2sUPXvVG9zvHONWylQrVUDinpzg4IPyaNwXq3S8la6pfBKZwEljE9IEuW2W6hMnKysiXdu2om+SVFRsNjV5eIbkdrei81wZnkiOE5ppp5R596YytpilgGgfM3BZyRZP0WbdTfxTJ1gBod2ohQeFfajGYjzNVju7pF2fghCeII8z6oPpb9uboqvpUS/gqThhgBAaUdkHrAQXrSq04qbfkCNw5x1AskJmBkiaB7ceoks2acYrSsJTcpwNwfGH+nSsvEMkLapYpy8l5heWqZezucUguhnqvWqG64CzP7R+hNrSWYjmJDSvmNmWXAT8behU7nCDfKqsZzK5JZ8mhi40io8TuYZwgbQMV+E6tlMUMlRFwJiaTRjQe15/CdARNL3e0tn0MvxlxAW78+50aOwxyUsaB0MWMqW0v6fGvqxEEFMsRFTlyI8/RwJf5pa5lol/o1OpoD3g7GA+k48QeuMYvIC7hluG+FZ1zoUCZxY0PZTv8OnLI7okksK1bCekx9vk7FpRkoIi8FOm98dtRxARD8mEnP5cVL4HikRcTwnO63XK24YcWKKXweeatUVM+d+i7YuC/kPTNbdhWzo7tgrkGO/YbO8kXax+3EFidzcLjPMCUFrOOv4whh8lCnetm1aVaDNVlxJcncGEPApL5M7aLiwiUnsuVXs8rH+YjZlTKf81sB23zaq4SLgIXk3sRLEp3I7yU6+Mq1loMEY5g6CpYe950CQVRq3pKvEyYBP7tuwWGxW8BEexM5QYaVpRZuVRAdd9OK4Gj19fTx+p1w9UUvCwmh/7QF4EckWm6w864R9/r0Xj3PeLQrXhO0xjXBl1yiK1lPqFhCp9CYABxIgxcMR80bA7jKE1xt4kjHcTUr6RPwsVZkWZw+VnFaWEMfBt3GryBwd2ldki139kFgEnNoRJjFdin3OPewPEjHc1TTfQQmMlBjRoYZDAhomX6d70B4MUDqMXHJA8wknj7n50JRJi6nacmVgW85uMv+eGGQL41xQSVoNs6uXuYOP/QSAWy8J4GBjYr8Q68jy4osYYmRl00SJt7klJEB0Dky1LfPF3PujU7i6+3Ltq1fGTiSaXkee8tdm1s3+DzgLvybx+io4q+LZlmMOlT17WEYnLaIpiQLjDt8KDcnaiUH8ep04dxsjrAGCUsdp08+kUpDPbZnH5aqXslaTjFUpRp05EAcIKnstROglEuvVEy7M59ulgtBMuYM+1YpZ+o6APVBrwTxqk91H3gFEmYGiMsJ+HVu/OWCsRS8knZWV6sMHKfPxxK2NNstBztxh6HHPCxe4eXBuN3lUnmrFeaZUie0CKgVZ8zVdlC2iSJnnu27jLORz5kQ91u1szx5Pu6kESV3inJuaChvJS51bLwPPTd2yRSPsp3hJQ8Huj9hPOBMcImLGLwM/QVz1sW8wWO7dOl8jrsMMjP8r8TNO9uC+tKiXDhGRp1IpvXZP667vMEu+FiwCGYt4eHvg23dcmp/JCqtsEsafbSlZl5NoQd9ybYNpV2Q0ucgYM2Ym30B9onqvktcUFWvMaYOoRUOUi2kA054IZzjWtbmNX1cmNNDVbr9efXN7vc0zYxJIHNJe7zrjb0TsQkOHoEmldq7gb0F+046rztHIhfv23cpA/PfEFRiY9UOo8+YmP6KQE5eZHq1YvCmXIfYx4YX64yJ4oVs8glT8WNP5jmZVzoJAOYMwTqETOY9TiXrHT6O0fO82KiuCZ2g9DyfivrSR2pdaqmrLw03olSu8mXKyw3Y66p4APTmbBLB+yytXAg3A9eJL/H/4oa8kjKzyApf37BgfPaKdcQFPv5dYTVo7OqfOhHDSzGQzxhn2AqDvPHlr1WuaEdNTP/xgu3yId2LFOa26UJvhiZUwwdKXN8azxs3GgpQhLktq9z9Fw==)

### Introduction

Mes choix pour ce projet sont les suivants:
- Mon projet est entièrement en anglais;
    - La raison pour cette décision est que je pensais rendre ce projet public
    sur GitHub, et l'anglais est assez universelle dans le monde de la
    programmation.
- J'ai complété ce projet individuellement;
    - En raison de l'incident du premier TP, mon coéquipier a décidé de
    travailler avec un autre partenaire et j'ai tenté moi aussi de me chercher
    un partenaire pour le projet mais je n'ai pas pu trouver une personne
    individuelle pour ce projet, puisque la plupart des équipes formées dans le
    premier TP ont demeuré pour le second. Et puisque la date des examens
    finaux approchait, j'ai décidé de commencer individuellement sur le projet
    pour ne pas perdre de temps d'attente d'un nouveau coéquipier et j'ai
    éventuellement finit le tout individuellement.
    
### Les listes

Mon programme utilise des listes simplement chaînées pour les structures
décrites dans l'énoncé dont quelques-unes possèdent des références au début de
la liste uniquement et d'autres possèdent des références au début et à la fin
de la liste.

Voici les détails d'implémentation:
- **Liste d'indexation**
    - Possède une référence au début et à la fin de la liste;
    - Ceci facilite l'ajout d'un document à la fin de la liste puisque les
    documents sont triés selon leur *date d'ajout*.
        - Chaque document possède une liste chaînée de mots couplé à une
        fréquence avec une référence vers le début de la liste uniquement;
        - Ceci facilite le triage lexicographique des mots qui est traité lors
        de l'ajout d'un mot et non après l'ajout.
- **Liste d'indexation inversé**
    - Possède une référence au début de la liste uniquement;
    - Ceci facilite le triage lexicographique des mots qui est traité lors
    de l'ajout d'un mot et non après l'ajout.
        - Chaque mot possède une liste chaînée de documents couplé à une
        fréquence avec une référence vers le début et la fin de la liste;
        - Ceci facilite l'ajout d'un document à la fin de la liste puisque les
        documents sont triés selon leur *date d'ajout*.
        
De plus, quelques structures supplémentaires de listes utilisées sont:
- Les **ArrayList** pour l'affichage de documents et leurs scores selon la
recherche de mots que fait l'usager;
- Les **HashList** pour empêcher des requêtes d'un usager contenant des entrées
dupliquées.
    - La méthode de HashList utilise un temps de complexité beaucoup plus
    réduit qu'une méthode de doubles boucles imbriquées.

### L'affichage

L'affichage des données se fait dans des objets de type **JTextArea** possédant
chacun un libellé l'identifiant et un **JScrollPane** pour faciliter la lecture
de gros rapports. Les **JTextArea** ne peuvent pas être modifiées par l'usager.
Les listes possèdent chacune une méthode *printList* permettant de convertir
leur contenu en une implémentation String et les noeuds qui ne sont pas des
listes possèdent la méthode toString indiquant leur implémentation
String.

### Fonction de recherche

La fonctionnalité de recherche suit de très près les directives énoncées:
- L'usager rentre sa requête dans un objet **JTextField** provenant d'un
dialogue;
    - Chaque entrée est séparée par une virgule et les caractères permis
    sont restreints à n'être uniquement que les caractères de l'alphabet, les
    chiffres et certains caractères spéciaux incluant la virgule.
- Si un mot dupliqué est détecté, une erreur s'affiche et l'usager doit
reformuler sa requête;
- La liste de résultats est conçue tel qu'indiqué dans l'énoncé:
    - Chaque document possède un score constituant la somme des fréquences de
    mots présents;
    - Si au moins un des mots de la requête ne figure pas dans le document,
    celui-ci n'est pas considéré dans la liste finale.
    - La liste est triée de manière descendante selon le score.
- Après la première requête, la liste de résultats est affichée et l'usager
peut décider de rajouter des mots à la requête à travers un dialogue semblable
au premier - les nouvelles entrées sont combinées avec la requête initiale pour
mettre-à-jour la liste de résultats.

### L'interface

La plupart des détails de l'interface graphique ont été discuté dans les
précédentes sections. J'aimerais noté ici que mon interface ne suit pas tout à
fait les directives exactes énoncées.
Voici les détails sur l'interface:
- Lorsque le programme est exécuté, la fenêtre principale apparaît;
    - Elle contient deux objets **JTextArea** pour contenir les listes
    d'indexation et d'indexation inversée.
    - Elle contient deux différents boutons décrivant l'action que chacun
    entreprend sur son libellé respectif:
        - Le bouton *Add Files* permet l'ajout de fichiers dans la liste
        d'indexation;
            - Un dialogue de type **JFileChooser** est employé pour la
            sélection de fichiers, les paramètres de ce dernier ont été
            modifiées pour accomoder aux besoins du programme.
            - L'ajout d'un fichier dans la liste d'indexation déclenche
            l'analyse du document et la mise-à-jour de la liste d'indexation
            inversée.
            - Un même fichier ne peut pas être ajouté plus d'une fois.
        - Le bouton *Search* permet d'initier la recherche de documents
        contenant les mots spécifiés;
            - Un dialogue contenant le **JTextField** et les boutons associés
            pour compléter la recherche est affiché.
            - Lorsque l'usager envoit sa première requête, une nouvelle fenêtre
            s'ouvre contenant un objet **JTextArea** pour contenir la liste de
            documents résultats couplées avec leur score.
                - Cette fenêtre contient un bouton *Add Words* permettant
                d'ajouter des mots supplémentaires à la recherche.

Ceci conlut la description de l'interface.

### Détails

Je voudrais adresser maintenant quelques détails sur la fonctionnalité du
programme:
1. Un même fichier ne peut pas être sélectionné une seconde fois, les chemins
absolus servent de comparaison. Cette décision a été adopté pour rendre les
résultats de recherche un peu plus intéressant.
1. Un mot ne peut pas être dupliqué lors d'une recherche. Cela est pour
empêcher des erreurs dans le calcul de fréquences.
1. Lorsque la fenêtre contenant la liste de résultat est ouverte, l'usager ne
peut pas accéder aux fonctionnalités qu'offre la fenêtre principale pour ne pas
interrompre l'état dans lequel se trouve le programme. Il pourrait cependant
positionner les fenêtres côte-à-côte pour entreprendre une recherche en ayant
les détails des listes à sa disposition.