/**
* The class Main begins the application
*
* @author Philippe Gabriel
* @version 1.0.1 2020-12-07
***/

public class Main {

    public static void main(String[] args) {

        mvc.SearchView.run();
    }
}